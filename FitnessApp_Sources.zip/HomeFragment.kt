package com.example.fitnessapp

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

data class FoodNutrition(
    val calories: Int,
    val proteinG: Float,
    val carbsG: Float,
    val fatG: Float
)

class HomeFragment : Fragment() {

    private var stepsText: TextView? = null
    private var caloriesText: TextView? = null
    private var distanceText: TextView? = null
    private var activeTimeText: TextView? = null
    private var stepsProgressText: TextView? = null
    private var stepsProgressBar: ProgressBar? = null
    private var stepsRemainingText: TextView? = null

    private var bCal = 0; private var bProtein = 0f; private var bCarbs = 0f; private var bFat = 0f
    private var lCal = 0; private var lProtein = 0f; private var lCarbs = 0f; private var lFat = 0f
    private var dCal = 0; private var dProtein = 0f; private var dCarbs = 0f; private var dFat = 0f

    private val foodDatabase = mapOf(
        "apple"             to FoodNutrition(95,   0.5f,  25f,  0.3f),
        "banana"            to FoodNutrition(105,  1.3f,  27f,  0.4f),
        "mango"             to FoodNutrition(99,   1.4f,  25f,  0.6f),
        "orange"            to FoodNutrition(62,   1.2f,  15f,  0.2f),
        "grapes"            to FoodNutrition(69,   0.7f,  18f,  0.2f),
        "papaya"            to FoodNutrition(59,   0.9f,  15f,  0.1f),
        "watermelon"        to FoodNutrition(30,   0.6f,   8f,  0.2f),
        "chicken breast"    to FoodNutrition(165, 31.0f,   0f,  3.6f),
        "chicken curry"     to FoodNutrition(240, 25.0f,   8f, 12.0f),
        "egg"               to FoodNutrition(78,   6.0f,   1f,  5.0f),
        "egg white"         to FoodNutrition(17,   3.6f,   0f,  0.1f),
        "boiled egg"        to FoodNutrition(78,   6.0f,   1f,  5.0f),
        "paneer"            to FoodNutrition(265, 18.0f,   4f, 20.0f),
        "paneer tikka"      to FoodNutrition(300, 20.0f,   8f, 21.0f),
        "dal"               to FoodNutrition(116,  8.0f,  20f,  0.4f),
        "dal tadka"         to FoodNutrition(150,  9.0f,  22f,  4.0f),
        "rajma"             to FoodNutrition(144,  8.7f,  26f,  0.5f),
        "chana"             to FoodNutrition(164,  8.9f,  27f,  2.6f),
        "fish"              to FoodNutrition(136, 20.0f,   0f,  6.0f),
        "tuna"              to FoodNutrition(132, 29.0f,   0f,  1.0f),
        "salmon"            to FoodNutrition(208, 20.0f,   0f, 13.0f),
        "mutton"            to FoodNutrition(258, 26.0f,   0f, 17.0f),
        "rice"              to FoodNutrition(206,  4.3f,  45f,  0.4f),
        "brown rice"        to FoodNutrition(215,  5.0f,  45f,  1.8f),
        "roti"              to FoodNutrition(104,  3.1f,  20f,  1.0f),
        "chapati"           to FoodNutrition(104,  3.1f,  20f,  1.0f),
        "paratha"           to FoodNutrition(260,  5.0f,  36f, 10.0f),
        "naan"              to FoodNutrition(262,  8.7f,  45f,  5.0f),
        "idli"              to FoodNutrition(39,   1.8f,   8f,  0.2f),
        "dosa"              to FoodNutrition(168,  3.9f,  32f,  3.7f),
        "oats"              to FoodNutrition(154,  5.0f,  28f,  3.0f),
        "poha"              to FoodNutrition(180,  3.0f,  36f,  3.0f),
        "upma"              to FoodNutrition(177,  4.0f,  30f,  5.0f),
        "pasta"             to FoodNutrition(220,  8.0f,  43f,  1.3f),
        "bread"             to FoodNutrition(79,   3.0f,  15f,  1.0f),
        "sandwich"          to FoodNutrition(250,  9.0f,  33f,  8.0f),
        "milk"              to FoodNutrition(122,  8.0f,  12f,  5.0f),
        "curd"              to FoodNutrition(61,   3.5f,   5f,  3.3f),
        "dahi"              to FoodNutrition(61,   3.5f,   5f,  3.3f),
        "yogurt"            to FoodNutrition(100,  17f,   6f,  0.7f),
        "greek yogurt"      to FoodNutrition(100,  17f,   6f,  0.7f),
        "cheese"            to FoodNutrition(113,  7.0f,   0f,  9.0f),
        "butter"            to FoodNutrition(102,  0.1f,   0f, 12.0f),
        "ghee"              to FoodNutrition(112,  0.0f,   0f, 12.5f),
        "samosa"            to FoodNutrition(262,  5.0f,  31f, 14.0f),
        "vada pav"          to FoodNutrition(290,  7.0f,  42f, 10.0f),
        "burger"            to FoodNutrition(354, 17.0f,  33f, 17.0f),
        "pizza"             to FoodNutrition(285, 12.0f,  36f, 10.0f),
        "french fries"      to FoodNutrition(365,  3.4f,  48f, 17.0f),
        "salad"             to FoodNutrition(50,   2.0f,   8f,  1.5f),
        "trail mix"         to FoodNutrition(173,  5.0f,  16f, 11.0f),
        "almonds"           to FoodNutrition(164,  6.0f,   6f, 14.0f),
        "peanuts"           to FoodNutrition(166,  7.0f,   6f, 14.0f),
        "protein shake"     to FoodNutrition(160, 30.0f,  10f,  3.0f),
        "lassi"             to FoodNutrition(150,  5.0f,  22f,  5.0f),
        "chai"              to FoodNutrition(60,   2.0f,   9f,  2.0f),
        "coffee"            to FoodNutrition(2,    0.3f,   0f,  0.0f),
        "juice"             to FoodNutrition(110,  0.5f,  26f,  0.3f)
    )

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "sync_steps" || key == "sync_distance" || key == "sync_calories" || key == "sync_active_min" || key == "user_name" || key == "step_goal") {
            activity?.runOnUiThread { refreshDashboard() }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        setupUI(view)
        refreshDashboard(view)
        return view
    }

    private fun setupUI(view: View) {
        stepsText      = view.findViewById(R.id.tv_home_steps)
        caloriesText   = view.findViewById(R.id.tv_home_calories)
        distanceText   = view.findViewById(R.id.tv_home_distance)
        activeTimeText = view.findViewById(R.id.tv_home_active_time)

        stepsProgressText  = view.findViewById(R.id.tv_step_count_progress)
        stepsRemainingText = view.findViewById(R.id.tv_steps_remaining)
        stepsProgressBar   = view.findViewById(R.id.pb_step_goal)

        val foodNameInput    = view.findViewById<android.widget.EditText>(R.id.edit_food_name)
        val logFoodButton    = view.findViewById<com.google.android.material.button.MaterialButton>(R.id.btn_add_food)
        val mealGroup        = view.findViewById<android.widget.RadioGroup>(R.id.rg_meals)
        val syncMfpBtn       = view.findViewById<TextView>(R.id.btn_sync_mfp)

        logFoodButton.setOnClickListener {
            val query = foodNameInput.text.toString().lowercase().trim()
            if (query.isNotEmpty()) {
                viewLifecycleOwner.lifecycleScope.launch {
                    var nutrition = FoodApiManager.getFoodNutrition(query)
                    if (nutrition == null) {
                        nutrition = foodDatabase[query] ?: foodDatabase.entries.firstOrNull { it.key.contains(query) }?.value
                    }
                    if (nutrition == null) {
                        nutrition = FoodNutrition((100..400).random(), (5..25).random().toFloat(), (10..60).random().toFloat(), (2..20).random().toFloat())
                    }

                    nutrition?.let {
                        when (mealGroup.checkedRadioButtonId) {
                            R.id.rb_breakfast -> { bCal += it.calories; bProtein += it.proteinG; bCarbs += it.carbsG; bFat += it.fatG }
                            R.id.rb_lunch     -> { lCal += it.calories; lProtein += it.proteinG; lCarbs += it.carbsG; lFat += it.fatG }
                            R.id.rb_dinner    -> { dCal += it.calories; dProtein += it.proteinG; dCarbs += it.carbsG; dFat += it.fatG }
                        }
                        refreshMacrosUI(view)
                        foodNameInput.setText("")
                        val msg = "${query.replaceFirstChar { it.uppercase() }}: ${it.calories} kcal"
                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        syncMfpBtn.setOnClickListener {
            val appUri = android.net.Uri.parse("myfitnesspal://")
            val webUri = android.net.Uri.parse("https://www.myfitnesspal.com/account/login")
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, appUri)
            try {
                startActivity(intent)
            } catch (e: Exception) {
                intent.data = webUri
                startActivity(intent)
            }
        }
    }

    private fun refreshDashboard(rootView: View? = null) {
        val view = rootView ?: view ?: return
        val context = context ?: return
        val sharedPref = context.getSharedPreferences("FitnessAppPrefs", Context.MODE_PRIVATE)

        val name         = sharedPref.getString("user_name", "Rahul")
        val stepGoalStr  = sharedPref.getString("step_goal", "10000") ?: "10000"
        val waterGoalStr = sharedPref.getString("water_goal", "2.5") ?: "2.5"
        val waterCurrent = sharedPref.getFloat("water_current", 0f)
        val bmi          = sharedPref.getFloat("user_bmi", 0f)

        val stepsStr     = sharedPref.getString("sync_steps", "0") ?: "0"
        val steps        = stepsStr.toIntOrNull() ?: 0
        val distance     = sharedPref.getString("sync_distance", "0.0") ?: "0.0"
        val calories     = sharedPref.getString("sync_calories", "0") ?: "0"
        val activeMin    = sharedPref.getString("sync_active_min", "0") ?: "0"
        val restingHR    = sharedPref.getInt("sync_resting_hr", 0)

        val stepGoal     = stepGoalStr.toIntOrNull() ?: 10000
        val waterGoal    = waterGoalStr.toFloatOrNull() ?: 2.5f

        val sdf          = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
        val currentDate  = sdf.format(Date())

        view.findViewById<TextView>(R.id.tv_home_greeting)?.text = "Good morning, $name 👋"
        view.findViewById<TextView>(R.id.tv_home_date)?.text     = "$currentDate - Let's crush your goals!"

        stepsText?.text    = String.format(Locale.getDefault(), "%,d", steps)
        distanceText?.text = "$distance" // Fitbit provides units, e.g. "4.2 km" or "2.6 mi"
        caloriesText?.text = calories
        activeTimeText?.text = "$activeMin min"

        stepsProgressText?.text = "${String.format(Locale.getDefault(), "%,d", steps)} / ${String.format(Locale.getDefault(), "%,d", stepGoal)}"
        val remaining = stepGoal - steps
        stepsRemainingText?.text = if (remaining > 0) "${String.format(Locale.getDefault(), "%,d", remaining)} steps remaining" else "Goal achieved! 🏆"

        val progressPercent = (steps.toFloat() / stepGoal.toFloat() * 100).toInt().coerceIn(0, 100)
        stepsProgressBar?.progress = progressPercent

        view.findViewById<TextView>(R.id.tv_home_water_progress)?.text = "${"%.1f".format(waterCurrent)}L / ${"%.1f".format(waterGoal)}L"
        val waterRemaining = waterGoal - waterCurrent
        view.findViewById<TextView>(R.id.tv_home_water_remaining)?.text = if (waterRemaining > 0) "${"%.1f".format(waterRemaining)}L remaining" else "Hydrated! 💧"

        val healthTipText = view.findViewById<TextView>(R.id.tv_home_health_tip)
        healthTipText?.text = when {
            restingHR > 0 -> "Resting HR: $restingHR bpm. ${if (restingHR < 70) "Excellent cardiovascular health!" else "Keep moving to strengthen your heart."}"
            bmi == 0f  -> "Set your height and weight in the Profile to get personalized tips!"
            bmi < 18.5 -> "Include more protein and healthy fats in your diet to build muscle."
            bmi < 25   -> "Keep it up! Consistency is key to maintaining your healthy weight."
            bmi < 30   -> "Try increasing your daily step goal by 2,000 to improve cardio health."
            else       -> "Consult with a nutritionist to create a sustainable low-calorie meal plan."
        }
        
        refreshMacrosUI(view)
    }

    private fun refreshMacrosUI(view: View) {
        val calorieResultText = view.findViewById<TextView>(R.id.tv_calorie_result)
        val macroSummaryText  = view.findViewById<TextView?>(R.id.tv_macro_summary)
        val macroProteinBar   = view.findViewById<ProgressBar?>(R.id.pb_protein)
        val macroCarbsBar     = view.findViewById<ProgressBar?>(R.id.pb_carbs)
        val macroFatBar       = view.findViewById<ProgressBar?>(R.id.pb_fat)
        val tvProteinLabel    = view.findViewById<TextView?>(R.id.tv_macro_protein)
        val tvCarbsLabel      = view.findViewById<TextView?>(R.id.tv_macro_carbs)
        val tvFatLabel        = view.findViewById<TextView?>(R.id.tv_macro_fat)

        val totalCal     = bCal + lCal + dCal
        val totalProtein = bProtein + lProtein + dProtein
        val totalCarbs   = bCarbs + lCarbs + dCarbs
        val totalFat     = bFat + lFat + dFat

        calorieResultText?.text = "Total: $totalCal kcal  •  B:$bCal  L:$lCal  D:$dCal kcal"
        calorieResultText?.setTextColor(resources.getColor(R.color.accent_purple, null))
        macroSummaryText?.text = "P: ${"%.1f".format(totalProtein)}g  •  C: ${"%.1f".format(totalCarbs)}g  •  F: ${"%.1f".format(totalFat)}g"

        tvProteinLabel?.text = "Protein  ${"%.1f".format(totalProtein)}g"
        tvCarbsLabel?.text   = "Carbs    ${"%.1f".format(totalCarbs)}g"
        tvFatLabel?.text     = "Fat      ${"%.1f".format(totalFat)}g"

        macroProteinBar?.progress = (totalProtein / 50f * 100).toInt().coerceIn(0, 100)
        macroCarbsBar?.progress   = (totalCarbs  / 250f * 100).toInt().coerceIn(0, 100)
        macroFatBar?.progress     = (totalFat    / 65f  * 100).toInt().coerceIn(0, 100)
    }

    override fun onResume() {
        super.onResume()
        val prefs = activity?.getSharedPreferences("FitnessAppPrefs", Context.MODE_PRIVATE)
        prefs?.registerOnSharedPreferenceChangeListener(prefListener)
        refreshDashboard()

        // Background sync from Fitbit whenever the user returns to the Dashboard
        context?.let { ctx ->
            if (FitbitManager.isAuthenticated(ctx)) {
                FitbitManager.syncNow(ctx) { _, _ ->
                    // UI will refresh via prefListener automatically
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        activity?.getSharedPreferences("FitnessAppPrefs", Context.MODE_PRIVATE)
            ?.unregisterOnSharedPreferenceChangeListener(prefListener)
    }
}
