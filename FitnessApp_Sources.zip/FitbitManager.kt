package com.example.fitnessapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

object FitbitManager {

    private const val CLIENT_ID    = "23V8YS"
    private const val CLIENT_SECRET = "4d84e071ea4eb750ad10e041dfb265b1"
    private const val REDIRECT_URI = "fitnessapp://fitbit-callback"
    private const val SCOPES       = "activity heartrate sleep profile"
    private const val PREFS_NAME   = "FitnessAppPrefs"

    private const val TAG = "FitbitManager"

    private const val AUTH_URL   = "https://www.fitbit.com/oauth2/authorize"
    private const val TOKEN_URL  = "https://api.fitbit.com/oauth2/token"
    private const val BASE_URL   = "https://api.fitbit.com/1/user/-"

    fun launchAuthFlow(context: Context) {
        val url = Uri.parse(AUTH_URL).buildUpon()
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("client_id",     CLIENT_ID)
            .appendQueryParameter("redirect_uri",  REDIRECT_URI)
            .appendQueryParameter("scope",         SCOPES)
            .appendQueryParameter("expires_in",    "604800")
            .build()

        val intent = Intent(Intent.ACTION_VIEW, url)
        context.startActivity(intent)
    }

    fun handleCallback(intent: Intent?, context: Context, onResult: (Boolean) -> Unit) {
        val uri = intent?.data ?: return
        if (uri.scheme != "fitnessapp" || uri.host != "fitbit-callback") return

        val code = uri.getQueryParameter("code")
        if (code.isNullOrEmpty()) {
            Log.e(TAG, "No authorization code in callback")
            onResult(false)
            return
        }

        Log.d(TAG, "Got auth code, exchanging for token...")
        exchangeCodeForToken(code, context, onResult)
    }

    private fun exchangeCodeForToken(
        code: String,
        context: Context,
        onResult: (Boolean) -> Unit
    ) {
        thread {
            try {
                val url = URL(TOKEN_URL)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                
                // Add Authorization header for Client Secret
                val authString = "$CLIENT_ID:$CLIENT_SECRET"
                val authBase64 = android.util.Base64.encodeToString(authString.toByteArray(), android.util.Base64.NO_WRAP)
                conn.setRequestProperty("Authorization", "Basic $authBase64")
                
                conn.doOutput = true
                conn.connectTimeout = 10_000
                conn.readTimeout    = 10_000

                val body = "grant_type=authorization_code" +
                    "&redirect_uri=${Uri.encode(REDIRECT_URI)}" +
                    "&code=$code"

                conn.outputStream.write(body.toByteArray())

                val responseCode = conn.responseCode
                val stream = if (responseCode == 200) conn.inputStream else conn.errorStream
                val response = BufferedReader(InputStreamReader(stream)).readText()

                if (responseCode == 200) {
                    val json = JSONObject(response)
                    val accessToken  = json.getString("access_token")
                    val refreshToken = json.getString("refresh_token")
                    val expiresIn    = json.getInt("expires_in")

                    saveTokens(context, accessToken, refreshToken, expiresIn)
                    Log.d(TAG, "Token exchange successful")
                    onResult(true)
                } else {
                    Log.e(TAG, "Token exchange failed ($responseCode): $response")
                    onResult(false)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Token exchange exception: ${e.message}")
                onResult(false)
            }
        }
    }

    data class FitbitActivityData(
        val steps: Int,
        val distanceKm: Double,
        val caloriesBurned: Int,
        val activeMinutes: Int,
        val heartRateResting: Int,
        val floorsClimbed: Int
    )

    fun fetchTodayActivity(
        context: Context,
        onSuccess: (FitbitActivityData) -> Unit,
        onError: (String) -> Unit
    ) {
        val token = getAccessToken(context)
        if (token.isNullOrEmpty()) {
            onError("Not authenticated. Please connect Fitbit first.")
            return
        }

        thread {
            try {
                val today    = getTodayDate()
                
                // 1. Fetch Activity Summary
                val summary  = fitbitGet("$BASE_URL/activities/date/$today.json", token)
                    ?: throw Exception("Failed to fetch activity data")

                val actSummary  = summary.getJSONObject("summary")
                val steps       = actSummary.optInt("steps", 0)
                val calories    = actSummary.optInt("caloriesOut", 0)
                val floors      = actSummary.optInt("floors", 0)
                
                // Fetch Active Zone Minutes (modern) or fairly/very active (older)
                val activeMin = actSummary.optInt("activeZoneMinutes", 
                                actSummary.optInt("fairlyActiveMinutes", 0) + 
                                actSummary.optInt("veryActiveMinutes", 0))

                val distancesArr = actSummary.optJSONArray("distances")
                var totalDist  = 0.0
                if (distancesArr != null) {
                    for (i in 0 until distancesArr.length()) {
                        val d = distancesArr.getJSONObject(i)
                        if (d.getString("activity") == "total") {
                            totalDist = d.getDouble("distance")
                            break
                        }
                    }
                }

                // 2. Fetch Heart Rate Data (Resting HR)
                val hrData = fitbitGet("$BASE_URL/activities/heart/date/$today/1d.json", token)
                var restingHeartRate = 0
                try {
                    val heartArr = hrData?.getJSONArray("activities-heart")
                    if (heartArr != null && heartArr.length() > 0) {
                        restingHeartRate = heartArr.getJSONObject(0)
                            .getJSONObject("value").optInt("restingHeartRate", 0)
                    }
                } catch (e: Exception) { Log.e(TAG, "HR parse error") }

                val data = FitbitActivityData(
                    steps           = steps,
                    distanceKm      = totalDist, 
                    caloriesBurned  = calories,
                    activeMinutes   = activeMin,
                    heartRateResting = restingHeartRate,
                    floorsClimbed   = floors
                )

                val prefs = context.getSharedPreferences("FitnessAppPrefs", Context.MODE_PRIVATE)
                prefs.edit()
                    .putString("sync_steps", steps.toString())
                    .putString("sync_distance", if (totalDist > 0) String.format(java.util.Locale.US, "%.2f", totalDist) else "0.0")
                    .putString("sync_calories", calories.toString())
                    .putString("sync_active_min", activeMin.toString())
                    .putInt("sync_resting_hr", restingHeartRate)
                    .apply()

                onSuccess(data)

            } catch (e: Exception) {
                Log.e(TAG, "fetchTodayActivity error: ${e.message}")
                onError("Could not load Fitbit data: ${e.message}")
            }
        }
    }

    fun saveSyncedActivity(context: Context, data: FitbitActivityData) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("sync_steps",      data.steps.toString())
            .putString("sync_distance",   "%.2f".format(data.distanceKm))
            .putString("sync_calories",   data.caloriesBurned.toString())
            .putString("sync_active_min", data.activeMinutes.toString())
            .putString("sync_hr",         data.heartRateResting.toString())
            .putString("sync_floors",     data.floorsClimbed.toString())
            .apply()
    }

    fun syncNow(
        context: Context,
        onComplete: (Boolean, String) -> Unit
    ) {
        if (!isAuthenticated(context)) {
            onComplete(false, "Not connected to Fitbit. Tap 'Connect Fitbit' first.")
            return
        }
        fetchTodayActivity(
            context = context,
            onSuccess = { data ->
                saveSyncedActivity(context, data)
                onComplete(
                    true,
                    "Synced from Fitbit: ${data.steps} steps, " +
                    "${"%.1f".format(data.distanceKm)} km, " +
                    "${data.caloriesBurned} kcal"
                )
            },
            onError = { msg -> onComplete(false, msg) }
        )
    }

    fun isAuthenticated(context: Context): Boolean =
        !getAccessToken(context).isNullOrEmpty()

    fun disconnect(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove("fitbit_access_token")
            .remove("fitbit_refresh_token")
            .remove("fitbit_token_expiry")
            .apply()
    }

    private fun fitbitGet(endpoint: String, token: String): JSONObject? {
        return try {
            val url  = URL(endpoint)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.connectTimeout = 10_000
            conn.readTimeout    = 10_000

            val code   = conn.responseCode
            val stream = if (code == 200) conn.inputStream else conn.errorStream
            val body   = BufferedReader(InputStreamReader(stream)).readText()

            if (code == 200) JSONObject(body) else null
        } catch (e: Exception) {
            Log.e(TAG, "GET $endpoint failed: ${e.message}")
            null
        }
    }

    private fun saveTokens(
        context: Context,
        accessToken: String,
        refreshToken: String,
        expiresIn: Int
    ) {
        val expiry = System.currentTimeMillis() + (expiresIn * 1000L)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString("fitbit_access_token",  accessToken)
            .putString("fitbit_refresh_token", refreshToken)
            .putLong("fitbit_token_expiry",    expiry)
            .apply()
    }

    private fun getAccessToken(context: Context): String? =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString("fitbit_access_token", null)

    private fun getTodayDate(): String {
        // Use Locale.US to ensure the date string is strictly yyyy-MM-dd regardless of device locale
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        return sdf.format(java.util.Date())
    }
}
