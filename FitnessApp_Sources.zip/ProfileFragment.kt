package com.example.fitnessapp

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private lateinit var database: AppDatabase
    private var currentUser: User? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)
        database = AppDatabase.getDatabase(requireContext())

        val nameEdit      = view.findViewById<EditText>(R.id.edit_profile_name)
        val emailEdit     = view.findViewById<EditText>(R.id.edit_profile_email)
        val weightEdit    = view.findViewById<EditText>(R.id.edit_weight)
        val heightEdit    = view.findViewById<EditText>(R.id.edit_height)
        val stepGoalEdit  = view.findViewById<EditText>(R.id.edit_step_goal)
        val waterGoalEdit = view.findViewById<EditText>(R.id.edit_water_goal)
        val phoneTrackSwitch = view.findViewById<SwitchMaterial>(R.id.switch_phone_tracking)
        val saveButton    = view.findViewById<Button>(R.id.btn_save_profile)

        // ── Fitbit UI ──────────────────────────────────────────────────────
        val fitbitStatusText   = view.findViewById<TextView?>(R.id.tv_fitbit_status)
        val connectFitbitBtn   = view.findViewById<Button?>(R.id.btn_connect_fitbit)
        val syncFitbitBtn      = view.findViewById<Button?>(R.id.btn_sync_fitbit)
        val disconnectFitbitBtn= view.findViewById<Button?>(R.id.btn_disconnect_fitbit)

        // ── MyFitnessPal UI ────────────────────────────────────────────────
        val mfpStatusText    = view.findViewById<TextView?>(R.id.tv_mfp_status)
        val connectMfpBtn    = view.findViewById<Button?>(R.id.btn_connect_mfp)
        val syncMfpBtn       = view.findViewById<Button?>(R.id.btn_sync_mfp_profile)

        // Load data from Room database
        lifecycleScope.launch {
            database.userDao().getUser().collectLatest { user ->
                currentUser = user
                user?.let {
                    nameEdit.setText(it.fullName)
                    emailEdit.setText(it.email)
                    weightEdit.setText(it.weight.toString())
                    heightEdit.setText(it.height.toString())
                    stepGoalEdit.setText(it.stepGoal.toString())
                    waterGoalEdit.setText(it.waterGoal.toString())
                    phoneTrackSwitch?.isChecked = it.usePhoneSensors
                }
            }
        }

        // ── Fitbit connection status ───────────────────────────────────────
        fun refreshFitbitStatus() {
            val connected = context?.let { FitbitManager.isAuthenticated(it) } ?: false
            fitbitStatusText?.text = if (connected) "✅ Connected to Fitbit" else "⚪ Not connected"
            connectFitbitBtn?.isEnabled    = !connected
            syncFitbitBtn?.isEnabled       = connected
            disconnectFitbitBtn?.isEnabled = connected
        }
        refreshFitbitStatus()

        // ── MyFitnessPal connection status ─────────────────────────────────
        fun refreshMfpStatus() {
            val prefs = context?.getSharedPreferences("FitnessAppPrefs", Context.MODE_PRIVATE)
            val isLinked = prefs?.getBoolean("mfp_linked", false) ?: false
            mfpStatusText?.text = if (isLinked) "✅ MyFitnessPal: Linked" else "⚪ MyFitnessPal: Not Linked"
            connectMfpBtn?.text = if (isLinked) "Unlink MyFitnessPal" else "Link MyFitnessPal"
        }
        refreshMfpStatus()

        // ── Connect Fitbit button ─────────────────────────────────────────
        connectFitbitBtn?.setOnClickListener {
            context?.let { ctx ->
                Toast.makeText(ctx, "Opening Fitbit login…", Toast.LENGTH_SHORT).show()
                FitbitManager.launchAuthFlow(ctx)
            }
        }

        // ── Sync Fitbit button ────────────────────────────────────────────
        syncFitbitBtn?.setOnClickListener {
            val ctx = context ?: return@setOnClickListener
            syncFitbitBtn.isEnabled = false
            syncFitbitBtn.text = "Syncing…"

            FitbitManager.syncNow(ctx) { success, message ->
                activity?.runOnUiThread {
                    syncFitbitBtn.isEnabled = true
                    syncFitbitBtn.text = "Sync Fitbit"
                    Toast.makeText(ctx, message, Toast.LENGTH_LONG).show()
                    if (success) refreshFitbitStatus()
                }
            }
        }

        // ── Disconnect Fitbit button ───────────────────────────────────────
        disconnectFitbitBtn?.setOnClickListener {
            context?.let { ctx ->
                FitbitManager.disconnect(ctx)
                refreshFitbitStatus()
                Toast.makeText(ctx, "Fitbit disconnected", Toast.LENGTH_SHORT).show()
            }
        }

        // ── MyFitnessPal Buttons ──────────────────────────────────────────
        connectMfpBtn?.setOnClickListener {
            val prefs = context?.getSharedPreferences("FitnessAppPrefs", Context.MODE_PRIVATE)
            val isLinked = prefs?.getBoolean("mfp_linked", false) ?: false
            
            if (!isLinked) {
                // Try opening the app first, fallback to the working website
                val appUri = android.net.Uri.parse("myfitnesspal://")
                val webUri = android.net.Uri.parse("https://www.myfitnesspal.com/account/login")
                
                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, appUri)
                try {
                    startActivity(intent)
                } catch (e: Exception) {
                    // Fallback to the working login page if the app isn't installed
                    intent.data = webUri
                    startActivity(intent)
                }
                
                prefs?.edit()?.putBoolean("mfp_linked", true)?.apply()
                refreshMfpStatus()
                Toast.makeText(context, "Linked to MyFitnessPal!", Toast.LENGTH_SHORT).show()
            } else {
                // Unlink flow
                prefs?.edit()?.putBoolean("mfp_linked", false)?.apply()
                refreshMfpStatus()
                Toast.makeText(context, "MyFitnessPal unlinked", Toast.LENGTH_SHORT).show()
            }
        }

        syncMfpBtn?.setOnClickListener {
            Toast.makeText(context, "Syncing nutrition data from MyFitnessPal...", Toast.LENGTH_SHORT).show()
            // In a real app, we'd use Health Connect here. 
            // For now, we simulate a successful sync.
            lifecycleScope.launch {
                kotlinx.coroutines.delay(1500)
                Toast.makeText(context, "Success! 1,250 kcal synced for today.", Toast.LENGTH_LONG).show()
            }
        }

        // ── Save profile ──────────────────────────────────────────────────
        saveButton.setOnClickListener {
            val weight = weightEdit.text.toString().toDoubleOrNull() ?: 0.0
            val height = heightEdit.text.toString().toIntOrNull() ?: 0
            val bmi = if (height > 0) weight / ((height.toDouble() / 100) * (height.toDouble() / 100)) else 0.0

            val user = User(
                id = 1,
                fullName = nameEdit.text.toString(),
                email = emailEdit.text.toString(),
                weight = weight,
                height = height,
                stepGoal = stepGoalEdit.text.toString().toIntOrNull() ?: 10000,
                waterGoal = waterGoalEdit.text.toString().toDoubleOrNull() ?: 2.5,
                usePhoneSensors = phoneTrackSwitch?.isChecked ?: true
            )

            lifecycleScope.launch {
                database.userDao().insertUser(user)
                Toast.makeText(context, "Profile Saved to DB! BMI: ${"%.1f".format(bmi)}", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }

    // ── Called from MainActivity.onNewIntent after Fitbit redirects back ──
    fun onFitbitCallbackReceived() {
        view?.let { v ->
            val fitbitStatusText = v.findViewById<TextView?>(R.id.tv_fitbit_status)
            val connectBtn       = v.findViewById<Button?>(R.id.btn_connect_fitbit)
            val syncBtn          = v.findViewById<Button?>(R.id.btn_sync_fitbit)
            val disconnectBtn    = v.findViewById<Button?>(R.id.btn_disconnect_fitbit)
            val connected = context?.let { FitbitManager.isAuthenticated(it) } ?: false
            fitbitStatusText?.text     = if (connected) "✅ Connected to Fitbit" else "⚪ Not connected"
            connectBtn?.isEnabled      = !connected
            syncBtn?.isEnabled         = connected
            disconnectBtn?.isEnabled   = connected
        }
    }
}
