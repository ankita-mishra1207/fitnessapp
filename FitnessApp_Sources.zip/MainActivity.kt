package com.example.fitnessapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0)
            insets
        }

        val navView: BottomNavigationView = findViewById(R.id.bottom_navigation)
        ViewCompat.setOnApplyWindowInsetsListener(navView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, 0, 0, systemBars.bottom)
            insets
        }
        navView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_dashboard -> {
                    loadFragment(HomeFragment())
                    true
                }
                R.id.navigation_workouts -> {
                    loadFragment(WorkoutFragment())
                    true
                }
                R.id.navigation_profile -> {
                    loadFragment(ProfileFragment())
                    true
                }
                else -> false
            }
        }

        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
            // Check if we were started by a Fitbit deep link (cold start)
            intent?.let { handleIntent(it) }
        }
    }

    private fun handleIntent(intent: Intent) {
        if (intent.data?.scheme == "fitnessapp") {
            FitbitManager.handleCallback(intent, this) { success ->
                runOnUiThread {
                    if (success) {
                        Toast.makeText(this, "✅ Fitbit connected!", Toast.LENGTH_LONG).show()

                        // Immediately sync data after connecting
                        FitbitManager.syncNow(this) { _, msg ->
                            runOnUiThread {
                                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                            }
                        }

                        // Refresh ProfileFragment UI if it's visible
                        val fragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
                        if (fragment is ProfileFragment) {
                            fragment.onFitbitCallbackReceived()
                        }
                    } else {
                        Toast.makeText(this, "Fitbit login failed.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}
